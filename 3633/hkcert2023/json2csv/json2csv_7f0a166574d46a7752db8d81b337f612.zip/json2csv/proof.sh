#!/bin/sh
echo hkcert23{fakeflag}