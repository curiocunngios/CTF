#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

char UUUwwUUU[0x20];
char* UwUUwUUwUUwU[0x10];

void setup() {
    setvbuf(stdin,NULL,2,0);
	setvbuf(stdout,NULL,2,0);
	setvbuf(stderr,NULL,2,0);
}

void UwU_menu() {
    puts("");
    puts("");
    printf("   ||        ||                           \n");
    printf("   ||        ||    ====                    \n");
    printf("   ||        ||        ||                  \n");
    printf("   ||        ||    ====                    \n");
    printf("   ||        ||        ||                  \n");
    printf("   ||        ||    ====                    \n");
    printf("   ||        ||                            \n");
    printf("     ========                                 \n");
    puts("");
    printf("   ========        O                O  \n");
    printf(" ||        ||      |\\      cɔ      /|  \n");
    printf(" ||        ||      | \\     /\\     / |  \n");
    printf(" ||        ||      |  \\   /  \\   /  |  \n");
    printf(" ||        ||      |   \\ /    \\ /   |  \n");
    printf(" ||        ||      |    V      V    |   \n");
    printf(" ||        ||      |                |   \n");
    printf(" ||        ||      |________________|   \n");
    puts("");
    puts("");
    puts("...");
    puts("");
    puts("- UwU");
    puts("- awa");
    puts("- QAQ");
    printf("> ");

    return;
}

int UwUInt(char s[], int a, int b){
    int num;

    printf("%s?\n", s);
    scanf("%d", &num);
    getchar();

    if (num < a || num >= b) {
        printf("%s...\n", s);
        exit(-1);
    }
    return num;
}

void UwU(){
    int index;
    int size;

    index = UwUInt("UwU", 0, 0x10);
    size = UwUInt("uWu", 0, 0x200);
    UwUUwUUwUUwU[index] = malloc(size);

    puts("UwU:");
    read(0, UwUUwUUwUUwU[index], size);
    puts("UwU!");
    return;
}   

void awa(){
    int index;

    index = UwUInt("awa", 0, 0x10);

    puts("awa:");
    if (UwUUwUUwUUwU[index] != NULL) {
        puts(UwUUwUUwUUwU[index]);
    }
    return;
}

void QAQ(){
    int index;

    index = UwUInt("QAQ", 0, 0x10);

    puts("QAq");
    if (UwUUwUUwUUwU[index] != NULL) {
        free(UwUUwUUwUUwU[index]);
        UwUUwUUwUUwU[index] = NULL;
    }
    return;
}


int main() {

	char UwU_buf[0x20] = {0};
    long long int UwU_num = 0;

    setup();

    while (1) {
        
        UwU_menu(); 
        UwU_num =  read(0, UwU_buf, 0x20);
        if (UwU_buf[UwU_num-1] == '\n')
            UwU_buf[UwU_num-1] = '\0';

        if (strcmp(UwU_buf, "UwU") == 0) UwU();
        else if (strcmp(UwU_buf, "awa") == 0) awa();
        else if (strcmp(UwU_buf, "QAQ") == 0) QAQ();
        else if (strcmp(UwU_buf, UUUwwUUU) == 0) {
            puts("UUUwwUUU!");
            exit(0);
        }
        else {
            puts("UwU...");    
            strcpy(UUUwwUUU, UwU_buf);
        }
    }
	return 0;
}